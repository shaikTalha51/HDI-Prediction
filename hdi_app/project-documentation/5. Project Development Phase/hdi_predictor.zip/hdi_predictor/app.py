"""
app.py
Flask web application for the Human Development Index (HDI) Predictor.

Routes:
- /             : Home page with project introduction
- /predict      : HDI prediction form (GET) and result handling (POST)
- /insights     : Displays EDA charts generated during analysis
"""

from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd
import os

app = Flask(__name__)

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")

with open(os.path.join(MODEL_DIR, "hdi_model.pkl"), "rb") as f:
    model = pickle.load(f)

with open(os.path.join(MODEL_DIR, "scaler.pkl"), "rb") as f:
    scaler = pickle.load(f)

with open(os.path.join(MODEL_DIR, "metadata.pkl"), "rb") as f:
    metadata = pickle.load(f)


def categorize(hdi):
    if hdi >= 0.80:
        return "Very High", "very-high"
    elif hdi >= 0.70:
        return "High", "high"
    elif hdi >= 0.55:
        return "Medium", "medium"
    else:
        return "Low", "low"


@app.route("/")
def home():
    return render_template("index.html", metadata=metadata)


@app.route("/predict", methods=["GET", "POST"])
def predict():
    result = None
    error = None
    form_values = {
        "life_expectancy": "",
        "mean_schooling": "",
        "expected_schooling": "",
        "gni": "",
    }

    if request.method == "POST":
        try:
            life_expectancy = float(request.form["life_expectancy"])
            mean_schooling = float(request.form["mean_schooling"])
            expected_schooling = float(request.form["expected_schooling"])
            gni = float(request.form["gni"])

            form_values.update({
                "life_expectancy": life_expectancy,
                "mean_schooling": mean_schooling,
                "expected_schooling": expected_schooling,
                "gni": gni,
            })

            # Basic validation ranges
            if not (0 <= life_expectancy <= 100):
                raise ValueError("Life expectancy must be between 0 and 100 years.")
            if not (0 <= mean_schooling <= 25):
                raise ValueError("Mean years of schooling must be between 0 and 25.")
            if not (0 <= expected_schooling <= 25):
                raise ValueError("Expected years of schooling must be between 0 and 25.")
            if gni <= 0:
                raise ValueError("GNI per capita must be a positive number.")

            features = pd.DataFrame([[life_expectancy, mean_schooling,
                                       expected_schooling, gni]],
                                     columns=metadata["feature_cols"])
            features_scaled = scaler.transform(features)
            prediction = model.predict(features_scaled)[0]
            prediction = float(np.clip(prediction, 0, 1))

            category, category_class = categorize(prediction)

            result = {
                "score": round(prediction, 3),
                "category": category,
                "category_class": category_class,
                "percentage": round(prediction * 100, 1),
            }

        except ValueError as ve:
            error = str(ve)
        except Exception:
            error = "Please enter valid numeric values for all fields."

    return render_template("predict.html", result=result, error=error,
                            form_values=form_values)


@app.route("/insights")
def insights():
    eda_dir = os.path.join(app.static_folder, "eda")
    charts_exist = os.path.isdir(eda_dir) and len(os.listdir(eda_dir)) > 0
    return render_template("insights.html", charts_exist=charts_exist,
                            metadata=metadata)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
