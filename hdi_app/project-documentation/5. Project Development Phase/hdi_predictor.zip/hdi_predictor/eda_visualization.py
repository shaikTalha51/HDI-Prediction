"""
eda_visualization.py
Performs Exploratory Data Analysis on the HDI dataset:
- Distribution plots
- Strip plots
- Correlation heatmap
- Scatter plots
Saves all charts into the static/ folder for reference / Flask display.
"""

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import os

os.makedirs("static/eda", exist_ok=True)

df = pd.read_csv("hdi_dataset.csv")
sns.set_style("whitegrid")

numeric_cols = ["Life_Expectancy", "Mean_Years_Schooling",
                 "Expected_Years_Schooling", "GNI_Per_Capita", "HDI_Score"]

# 1. Distribution plots
fig, axes = plt.subplots(2, 3, figsize=(16, 9))
for ax, col in zip(axes.flat, numeric_cols):
    sns.histplot(df[col].dropna(), kde=True, ax=ax, color="#4C72B0")
    ax.set_title(f"Distribution of {col}")
axes.flat[-1].axis("off")
plt.tight_layout()
plt.savefig("static/eda/distributions.png", dpi=120)
plt.close()

# 2. Strip plot - HDI Category vs Life Expectancy
plt.figure(figsize=(8, 5))
sns.stripplot(data=df, x="HDI_Category", y="Life_Expectancy",
              order=["Low", "Medium", "High", "Very High"],
              palette="viridis", jitter=True)
plt.title("Life Expectancy across HDI Categories")
plt.tight_layout()
plt.savefig("static/eda/stripplot.png", dpi=120)
plt.close()

# 3. Correlation heatmap
plt.figure(figsize=(7, 6))
corr = df[numeric_cols].corr()
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Matrix")
plt.tight_layout()
plt.savefig("static/eda/heatmap.png", dpi=120)
plt.close()

# 4. Scatter plots vs HDI Score
fig, axes = plt.subplots(1, 4, figsize=(20, 4.5))
features = ["Life_Expectancy", "Mean_Years_Schooling", "Expected_Years_Schooling", "GNI_Per_Capita"]
for ax, col in zip(axes, features):
    sns.scatterplot(data=df, x=col, y="HDI_Score", hue="HDI_Category", ax=ax, legend=(col == features[-1]))
    ax.set_title(f"{col} vs HDI Score")
plt.tight_layout()
plt.savefig("static/eda/scatterplots.png", dpi=120)
plt.close()

print("EDA complete. Charts saved in static/eda/")
