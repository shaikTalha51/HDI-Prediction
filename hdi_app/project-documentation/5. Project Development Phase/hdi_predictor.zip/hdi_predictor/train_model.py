"""
train_model.py
- Loads the HDI dataset
- Handles missing values (mean imputation)
- Label-encodes the target category
- Splits into train/test sets
- Trains a Linear Regression model to predict HDI_Score
- Evaluates with R-squared and reports accuracy by category
- Saves the trained model + scaler + label encoder using pickle
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import pickle
import os

os.makedirs("model", exist_ok=True)

# 1. Load dataset
df = pd.read_csv("hdi_dataset.csv")
print(f"Loaded dataset: {df.shape}")

# 2. Handle missing values - fill with column mean
feature_cols = ["Life_Expectancy", "Mean_Years_Schooling",
                 "Expected_Years_Schooling", "GNI_Per_Capita"]

for col in feature_cols:
    if df[col].isna().sum() > 0:
        mean_val = df[col].mean()
        df[col] = df[col].fillna(mean_val)
        print(f"Filled {col} missing values with mean: {mean_val:.2f}")

# 3. Label encode the HDI Category (kept for reference / classification use)
le = LabelEncoder()
df["HDI_Category_Encoded"] = le.fit_transform(df["HDI_Category"])
print(f"Label classes: {list(le.classes_)}")

# 4. Select dependent (y) and independent (X) variables
X = df[feature_cols]
y = df["HDI_Score"]

# 5. Feature scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 6. Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)
print(f"Train size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")

# 7. Fit Linear Regression model
model = LinearRegression()
model.fit(X_train, y_train)

# 8. Evaluate
y_pred = model.predict(X_test)
r2 = r2_score(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

print("\n--- Model Performance ---")
print(f"R-Squared: {r2:.4f}")
print(f"MAE: {mae:.4f}")
print(f"RMSE: {rmse:.4f}")
print(f"Coefficients: {dict(zip(feature_cols, model.coef_))}")
print(f"Intercept: {model.intercept_:.4f}")


def categorize(hdi):
    if hdi >= 0.80:
        return "Very High"
    elif hdi >= 0.70:
        return "High"
    elif hdi >= 0.55:
        return "Medium"
    else:
        return "Low"


# 9. Save model, scaler, and label encoder via pickle
with open("model/hdi_model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("model/scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)

with open("model/label_encoder.pkl", "wb") as f:
    pickle.dump(le, f)

metadata = {
    "feature_cols": feature_cols,
    "r2_score": round(r2, 4),
    "mae": round(mae, 4),
    "rmse": round(rmse, 4),
}
with open("model/metadata.pkl", "wb") as f:
    pickle.dump(metadata, f)

print("\nModel, scaler, label encoder, and metadata saved to model/ directory.")
