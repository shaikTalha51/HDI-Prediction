"""
generate_dataset.py
Generates a realistic synthetic Human Development Index (HDI) dataset
covering Life Expectancy, Mean Years of Schooling, Expected Years of
Schooling, GNI per Capita, and the resulting HDI Score + Category.

This mirrors the structure of real-world HDI datasets (like UNDP's)
so the rest of the pipeline (EDA, preprocessing, model training,
Flask deployment) works exactly as it would on real data.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

countries = [
    "Norway", "Switzerland", "Ireland", "Germany", "Iceland", "Hong Kong",
    "Australia", "Sweden", "Netherlands", "Denmark", "Finland", "Singapore",
    "United Kingdom", "Belgium", "New Zealand", "Canada", "United States",
    "Japan", "South Korea", "France", "Spain", "Italy", "Israel", "Austria",
    "Slovenia", "Poland", "Portugal", "Chile", "Saudi Arabia", "Hungary",
    "Argentina", "Croatia", "Russia", "Romania", "Turkey", "Malaysia",
    "China", "Brazil", "Mexico", "Thailand", "Sri Lanka", "Vietnam",
    "Indonesia", "Philippines", "South Africa", "Egypt", "India",
    "Bangladesh", "Bhutan", "Kenya", "Ghana", "Nigeria", "Pakistan",
    "Nepal", "Cambodia", "Myanmar", "Zambia", "Senegal", "Rwanda",
    "Ethiopia", "Haiti", "Yemen", "Sudan", "Afghanistan", "Niger",
    "Chad", "Mali", "Burundi", "Mozambique", "Sierra Leone", "Guinea",
    "Central African Republic", "South Sudan", "Liberia", "Malawi",
    "Uganda", "Tanzania", "Madagascar", "Togo", "Burkina Faso", "Yemen2",
    "Jordan", "Lebanon", "Morocco", "Tunisia", "Algeria", "Peru",
    "Colombia", "Ecuador", "Bolivia", "Paraguay", "Uruguay", "Panama",
    "Costa Rica", "Jamaica", "Cuba", "Dominican Republic", "Guatemala",
    "Honduras", "El Salvador", "Nicaragua", "Greece", "Cyprus"
]

n = len(countries)

# Generate a "true" development tier per country (drives correlated features)
tier = np.random.choice([0, 1, 2, 3], size=n, p=[0.25, 0.30, 0.25, 0.20])
# 0 = Very High, 1 = High, 2 = Medium, 3 = Low  (we will map this to ranges)

life_expectancy = []
mean_schooling = []
expected_schooling = []
gni_per_capita = []

for t in tier:
    if t == 0:  # Very High
        life_expectancy.append(np.random.uniform(78, 85))
        mean_schooling.append(np.random.uniform(11.5, 14.5))
        expected_schooling.append(np.random.uniform(16, 19))
        gni_per_capita.append(np.random.uniform(35000, 90000))
    elif t == 1:  # High
        life_expectancy.append(np.random.uniform(72, 78))
        mean_schooling.append(np.random.uniform(8.5, 11.5))
        expected_schooling.append(np.random.uniform(13, 16))
        gni_per_capita.append(np.random.uniform(12000, 35000))
    elif t == 2:  # Medium
        life_expectancy.append(np.random.uniform(65, 72))
        mean_schooling.append(np.random.uniform(5.5, 8.5))
        expected_schooling.append(np.random.uniform(10, 13))
        gni_per_capita.append(np.random.uniform(3500, 12000))
    else:  # Low
        life_expectancy.append(np.random.uniform(50, 65))
        mean_schooling.append(np.random.uniform(1.5, 5.5))
        expected_schooling.append(np.random.uniform(5, 10))
        gni_per_capita.append(np.random.uniform(500, 3500))

df = pd.DataFrame({
    "Country": countries,
    "Life_Expectancy": np.round(life_expectancy, 1),
    "Mean_Years_Schooling": np.round(mean_schooling, 1),
    "Expected_Years_Schooling": np.round(expected_schooling, 1),
    "GNI_Per_Capita": np.round(gni_per_capita, 0)
})

# Inject a few missing values to make preprocessing meaningful (as in real datasets)
missing_idx = np.random.choice(df.index, size=6, replace=False)
for idx in missing_idx:
    col = np.random.choice(["Life_Expectancy", "Mean_Years_Schooling",
                             "Expected_Years_Schooling", "GNI_Per_Capita"])
    df.loc[idx, col] = np.nan


def normalize(value, lo, hi):
    return min(max((value - lo) / (hi - lo), 0), 1)


def compute_hdi(row):
    le = row["Life_Expectancy"] if not pd.isna(row["Life_Expectancy"]) else df["Life_Expectancy"].mean()
    ms = row["Mean_Years_Schooling"] if not pd.isna(row["Mean_Years_Schooling"]) else df["Mean_Years_Schooling"].mean()
    es = row["Expected_Years_Schooling"] if not pd.isna(row["Expected_Years_Schooling"]) else df["Expected_Years_Schooling"].mean()
    gni = row["GNI_Per_Capita"] if not pd.isna(row["GNI_Per_Capita"]) else df["GNI_Per_Capita"].mean()

    life_index = normalize(le, 20, 85)
    edu_index = (normalize(ms, 0, 15) + normalize(es, 0, 18)) / 2
    income_index = normalize(np.log(gni), np.log(100), np.log(100000))

    hdi = (life_index * edu_index * income_index) ** (1 / 3)
    return round(hdi, 3)


df["HDI_Score"] = df.apply(compute_hdi, axis=1)


def categorize(hdi):
    if hdi >= 0.80:
        return "Very High"
    elif hdi >= 0.70:
        return "High"
    elif hdi >= 0.55:
        return "Medium"
    else:
        return "Low"


df["HDI_Category"] = df["HDI_Score"].apply(categorize)

df.to_csv("hdi_dataset.csv", index=False)
print(f"Dataset generated: {df.shape[0]} rows, {df.shape[1]} columns")
print(df.head(10))
print("\nCategory distribution:")
print(df["HDI_Category"].value_counts())
