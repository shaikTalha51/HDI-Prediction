# Human Development Index (HDI) Predictor

A complete ML + Flask project that predicts a country's Human Development Index
from Life Expectancy, Mean Years of Schooling, Expected Years of Schooling, and
GNI per Capita.

## Project Structure

```
hdi_predictor/
├── generate_dataset.py     # Creates hdi_dataset.csv (103 countries, realistic values)
├── eda_visualization.py    # Generates EDA charts into static/eda/
├── train_model.py          # Preprocessing, training, evaluation, pickle saving
├── app.py                  # Flask web application
├── requirements.txt
├── hdi_dataset.csv         # Generated dataset
├── model/
│   ├── hdi_model.pkl        # Trained Linear Regression model
│   ├── scaler.pkl           # StandardScaler used on features
│   ├── label_encoder.pkl    # LabelEncoder for HDI category
│   └── metadata.pkl         # Feature list + R²/MAE/RMSE
├── templates/
│   ├── base.html
│   ├── index.html           # Overview / home page
│   ├── predict.html         # Prediction form + result
│   └── insights.html        # EDA chart gallery
└── static/
    ├── css/style.css        # Dark glassmorphism UI
    └── eda/                 # Generated chart images
```

## Setup

```bash
cd hdi_predictor
pip install -r requirements.txt
```

## Run the full pipeline (already done once, re-run any time)

```bash
python generate_dataset.py     # 1. Build the dataset
python eda_visualization.py    # 2. Generate EDA charts
python train_model.py          # 3. Train + save the model
```

## Run the web app

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## Model Performance

- **Algorithm:** Linear Regression (Scikit-learn)
- **R-Squared:** ~0.985
- **MAE:** ~0.019
- **RMSE:** ~0.025

## Routes

| Route       | Description                                  |
|-------------|-----------------------------------------------|
| `/`         | Project overview, HDI explanation, scenarios |
| `/predict`  | Input form → predicted HDI score + category  |
| `/insights` | EDA charts (distributions, heatmap, scatter) |

## Notes

- The dataset is synthetically generated with realistic, correlated values
  matching real-world HDI dataset structure (Country, Life Expectancy, Mean/Expected
  Years of Schooling, GNI per Capita, HDI Score, HDI Category) — swap in a real
  Kaggle HDI CSV with the same column names and rerun the pipeline if you have one.
- Missing values are handled via mean imputation in `train_model.py`.
- All four indicators are scaled with `StandardScaler` before being fed to the model.
